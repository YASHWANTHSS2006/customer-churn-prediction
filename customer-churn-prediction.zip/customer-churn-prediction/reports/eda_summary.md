Customers: 7,043 | Overall churn rate: 26.5%

### Contract

| Contract       |   customers |   churn_rate |
|:---------------|------------:|-------------:|
| Month-to-month |        3875 |         42.7 |
| One year       |        1473 |         11.3 |
| Two year       |        1695 |          2.8 |

### tenure_group

| tenure_group   |   customers |   churn_rate |
|:---------------|------------:|-------------:|
| 0-12           |        2186 |         47.4 |
| 13-24          |        1024 |         28.7 |
| 25-48          |        1594 |         20.4 |
| 49-72          |        2239 |          9.5 |

### InternetService

| InternetService   |   customers |   churn_rate |
|:------------------|------------:|-------------:|
| Fiber optic       |        3096 |         41.9 |
| DSL               |        2421 |         19   |
| No                |        1526 |          7.4 |

### PaymentMethod

| PaymentMethod             |   customers |   churn_rate |
|:--------------------------|------------:|-------------:|
| Electronic check          |        2365 |         45.3 |
| Mailed check              |        1612 |         19.1 |
| Bank transfer (automatic) |        1544 |         16.7 |
| Credit card (automatic)   |        1522 |         15.2 |
