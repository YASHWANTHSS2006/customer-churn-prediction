"""Train and compare churn models, then save metrics, figures and the best model.

Run from the project root:  python src/train.py
"""
import json
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, RocCurveDisplay, confusion_matrix,
                             f1_score, precision_recall_curve, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_val_predict, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from data import load_clean, add_features, split_xy

SEED = 42
ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
FIG = REPORTS / "figures"
MODELS = ROOT / "models"
for d in (FIG, MODELS):
    d.mkdir(parents=True, exist_ok=True)


def build_preprocessor(X):
    num = X.select_dtypes(include="number").columns.tolist()
    cat = [c for c in X.columns if c not in num]
    return ColumnTransformer([
        ("num", StandardScaler(), num),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), cat),
    ])


def get_models(X):
    def pipe(clf):
        return Pipeline([("prep", build_preprocessor(X)), ("clf", clf)])
    return {
        "Logistic Regression": pipe(LogisticRegression(C=0.5, max_iter=3000, class_weight="balanced")),
        "Random Forest": pipe(RandomForestClassifier(
            n_estimators=300, min_samples_leaf=10, class_weight="balanced_subsample",
            n_jobs=-1, random_state=SEED)),
        "Hist Gradient Boosting": pipe(HistGradientBoostingClassifier(
            learning_rate=0.05, max_iter=200, max_depth=4, min_samples_leaf=30,
            l2_regularization=1.0, class_weight="balanced", random_state=SEED)),
    }


def best_f2_threshold(y_true, proba, beta=2.0):
    """Threshold that maximises F-beta (recall-weighted) on out-of-fold predictions."""
    p, r, t = precision_recall_curve(y_true, proba)
    f = (1 + beta**2) * p[:-1] * r[:-1] / np.clip(beta**2 * p[:-1] + r[:-1], 1e-9, None)
    return float(t[np.argmax(f)])


def scores(y_true, proba, thr):
    pred = (proba >= thr).astype(int)
    return {
        "threshold": round(float(thr), 3),
        "recall": round(recall_score(y_true, pred), 3),
        "precision": round(precision_score(y_true, pred), 3),
        "f1": round(f1_score(y_true, pred), 3),
    }


def main():
    df = add_features(load_clean())
    X, y = split_xy(df)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
    print(f"Train {len(X_tr):,} | Test {len(X_te):,} | churn rate {y.mean():.3f}")

    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    models = get_models(X)
    results = {}

    # 1. Compare models with 5-fold CV on the training set only.
    for name, m in models.items():
        auc = cross_val_score(m, X_tr, y_tr, cv=cv, scoring="roc_auc", n_jobs=1)
        results[name] = {"cv_auc_mean": round(auc.mean(), 4), "cv_auc_std": round(auc.std(), 4)}
        print(f"{name:24s} CV ROC-AUC {auc.mean():.4f} +/- {auc.std():.4f}")

    best_name = max(results, key=lambda k: results[k]["cv_auc_mean"])
    print("Selected on CV:", best_name)

    # 2. Pick the decision threshold on out-of-fold predictions (train only, no test leakage).
    oof = cross_val_predict(models[best_name], X_tr, y_tr, cv=cv, method="predict_proba")[:, 1]
    thr = best_f2_threshold(y_tr, oof)

    # 3. Final evaluation on the untouched test set.
    test_proba = {}
    for name, m in models.items():
        m.fit(X_tr, y_tr)
        p = m.predict_proba(X_te)[:, 1]
        test_proba[name] = p
        results[name]["test_auc"] = round(roc_auc_score(y_te, p), 4)
        results[name]["test_at_0.5"] = scores(y_te, p, 0.5)
    best = models[best_name]
    results[best_name]["test_at_tuned_threshold"] = scores(y_te, test_proba[best_name], thr)

    # Rule baseline: flag every month-to-month customer.
    rule = (X_te["Contract"] == "Month-to-month").astype(int)
    baseline = {
        "recall": round(recall_score(y_te, rule), 3),
        "precision": round(precision_score(y_te, rule), 3),
        "flagged_share": round(float(rule.mean()), 3),
    }

    # 4. Business view: how much churning revenue sits in the top-scored customers.
    p = test_proba[best_name]
    order = np.argsort(-p)
    n = len(p)
    ytest = y_te.to_numpy()[order]
    monthly = X_te["MonthlyCharges"].to_numpy()[order]
    base_rate = y_te.mean()
    top_dec = ytest[: n // 10].mean()
    top20 = slice(0, n // 5)
    business = {
        "base_churn_rate": round(float(base_rate), 3),
        "top_decile_churn_rate": round(float(top_dec), 3),
        "top_decile_lift": round(float(top_dec / base_rate), 2),
        "top20pct_share_of_churners_caught": round(float(ytest[top20].sum() / ytest.sum()), 3),
        "top20pct_share_of_churning_monthly_revenue": round(
            float(monthly[top20][ytest[top20] == 1].sum() / monthly[ytest == 1].sum()), 3),
        "churning_monthly_revenue_in_test": round(float(monthly[ytest == 1].sum()), 2),
    }

    # 5. Which inputs matter? Permutation importance on the test set (original columns).
    imp = permutation_importance(best, X_te, y_te, scoring="roc_auc", n_repeats=10,
                                 random_state=SEED, n_jobs=1)
    imp_df = (pd.DataFrame({"feature": X.columns, "auc_drop": imp.importances_mean,
                            "std": imp.importances_std})
              .sort_values("auc_drop", ascending=False).reset_index(drop=True))
    imp_df.round(4).to_csv(REPORTS / "feature_importance.csv", index=False)

    # Figures
    fig, ax = plt.subplots(figsize=(6, 5))
    for name, pr in test_proba.items():
        RocCurveDisplay.from_predictions(y_te, pr, name=f"{name} (AUC {results[name]['test_auc']:.3f})", ax=ax)
    ax.plot([0, 1], [0, 1], "k--", lw=1)
    ax.set_title("ROC curves on test set")
    fig.tight_layout(); fig.savefig(FIG / "roc_curves.png", dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    ConfusionMatrixDisplay(confusion_matrix(y_te, (p >= thr).astype(int)),
                           display_labels=["Stayed", "Churned"]).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"{best_name}\nthreshold {thr:.2f}")
    fig.tight_layout(); fig.savefig(FIG / "confusion_matrix.png", dpi=130); plt.close(fig)

    top = imp_df.head(10).iloc[::-1]
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.barh(top["feature"], top["auc_drop"], xerr=top["std"], color="#3b6ea5")
    ax.set_xlabel("Drop in test ROC-AUC when feature is shuffled")
    ax.set_title("Top 10 churn drivers (permutation importance)")
    fig.tight_layout(); fig.savefig(FIG / "feature_importance.png", dpi=130); plt.close(fig)

    gains_x = np.arange(1, n + 1) / n
    gains_y = np.cumsum(ytest) / ytest.sum()
    fig, ax = plt.subplots(figsize=(5.5, 4.2))
    ax.plot(gains_x, gains_y, label=best_name, color="#3b6ea5")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random targeting")
    ax.set_xlabel("Share of customers contacted (highest risk first)")
    ax.set_ylabel("Share of churners reached")
    ax.set_title("Cumulative gains")
    ax.legend()
    fig.tight_layout(); fig.savefig(FIG / "gains_curve.png", dpi=130); plt.close(fig)

    # Save model + metrics
    joblib.dump({"model": best, "threshold": thr, "features": list(X.columns)}, MODELS / "churn_model.joblib")
    out = {"selected_model": best_name, "n_train": len(X_tr), "n_test": len(X_te),
           "models": results, "rule_baseline_month_to_month": baseline, "business": business,
           "top_features": imp_df.head(5).round(4).to_dict("records")}
    (REPORTS / "metrics.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
