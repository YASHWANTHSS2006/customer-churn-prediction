"""Data loading, cleaning and feature engineering for the Telco churn project."""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "telco_churn.csv"

ADDON_COLS = [
    "OnlineSecurity", "OnlineBackup", "DeviceProtection",
    "TechSupport", "StreamingTV", "StreamingMovies",
]
AUTOPAY = ("Bank transfer (automatic)", "Credit card (automatic)")


def load_clean(path=DATA_PATH):
    """Load the raw CSV and fix known data issues.

    TotalCharges is stored as text; 11 rows are blank. All 11 have tenure = 0
    (customers who have not been billed yet), so they are set to 0.
    """
    df = pd.read_csv(path)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    blank = df["TotalCharges"].isna()
    assert (df.loc[blank, "tenure"] == 0).all(), "blank TotalCharges with tenure > 0"
    df.loc[blank, "TotalCharges"] = 0.0
    df["Churn"] = (df["Churn"] == "Yes").astype(int)
    return df


def add_features(df):
    """Add engineered features. Returns a new frame without customerID."""
    out = df.copy()
    out["n_addons"] = sum((out[c] == "Yes").astype(int) for c in ADDON_COLS)
    out["is_autopay"] = out["PaymentMethod"].isin(AUTOPAY).astype(int)
    out["has_family"] = ((out["Partner"] == "Yes") | (out["Dependents"] == "Yes")).astype(int)
    out["avg_monthly_spend"] = np.where(
        out["tenure"] > 0, out["TotalCharges"] / out["tenure"].clip(lower=1), out["MonthlyCharges"]
    )
    out["tenure_group"] = pd.cut(
        out["tenure"], bins=[-1, 12, 24, 48, 72],
        labels=["0-12", "13-24", "25-48", "49-72"],
    ).astype(str)
    return out.drop(columns=["customerID"])


def split_xy(df):
    y = df["Churn"]
    X = df.drop(columns=["Churn"])
    return X, y
