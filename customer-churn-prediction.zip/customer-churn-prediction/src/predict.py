"""Score customers with the trained churn model.

Usage (from project root, after running  python src/train.py):
    python src/predict.py data/telco_churn.csv --top 10
"""
import argparse
from pathlib import Path

import joblib
import pandas as pd

from data import add_features

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "churn_model.joblib"


def load_bundle(path=MODEL_PATH):
    if not Path(path).exists():
        raise FileNotFoundError("Model not found. Run  python src/train.py  first.")
    return joblib.load(path)


def score_frame(raw, bundle=None):
    """Return a copy of raw customer rows with churn_risk (0-1) and high_risk flag."""
    bundle = bundle or load_bundle()
    df = raw.copy()
    if "customerID" not in df.columns:
        df["customerID"] = range(len(df))
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0.0)
    feats = add_features(df.drop(columns=["Churn"], errors="ignore"))[bundle["features"]]
    proba = bundle["model"].predict_proba(feats)[:, 1]
    out = raw.copy()
    out["churn_risk"] = proba.round(3)
    out["high_risk"] = proba >= bundle["threshold"]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", help="CSV with the same columns as the Telco dataset")
    ap.add_argument("--top", type=int, default=10, help="show the N highest-risk customers")
    args = ap.parse_args()
    scored = score_frame(pd.read_csv(args.csv))
    cols = [c for c in ["customerID", "Contract", "tenure", "MonthlyCharges", "churn_risk", "high_risk"]
            if c in scored.columns]
    print(scored.sort_values("churn_risk", ascending=False)[cols].head(args.top).to_string(index=False))


if __name__ == "__main__":
    main()
