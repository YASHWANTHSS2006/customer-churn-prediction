"""Exploratory data analysis: churn rate by key segments, saved as figures and a markdown table."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from data import load_clean, add_features

OUT = Path(__file__).resolve().parents[1] / "reports"
FIG = OUT / "figures"
FIG.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid")


def rate_table(df, col):
    t = df.groupby(col)["Churn"].agg(customers="count", churn_rate="mean")
    t["churn_rate"] = (t["churn_rate"] * 100).round(1)
    return t.sort_values("churn_rate", ascending=False)


def bar(df, col, fname, title):
    t = rate_table(df, col).reset_index()
    fig, ax = plt.subplots(figsize=(6.5, 4))
    sns.barplot(data=t, x=col, y="churn_rate", color="#3b6ea5", ax=ax)
    ax.axhline(df["Churn"].mean() * 100, color="#c0392b", ls="--", lw=1, label="Overall churn rate")
    for p in ax.patches:
        ax.annotate(f"{p.get_height():.1f}%", (p.get_x() + p.get_width() / 2, p.get_height()),
                    ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Churn rate (%)")
    ax.set_title(title)
    ax.legend()
    plt.setp(ax.get_xticklabels(), rotation=15, ha="right")
    fig.tight_layout()
    fig.savefig(FIG / fname, dpi=130)
    plt.close(fig)


def main():
    df = add_features(load_clean())
    lines = [f"Customers: {len(df):,} | Overall churn rate: {df['Churn'].mean() * 100:.1f}%\n"]
    for col, fname, title in [
        ("Contract", "churn_by_contract.png", "Churn rate by contract type"),
        ("tenure_group", "churn_by_tenure.png", "Churn rate by tenure (months)"),
        ("InternetService", "churn_by_internet.png", "Churn rate by internet service"),
        ("PaymentMethod", "churn_by_payment.png", "Churn rate by payment method"),
    ]:
        bar(df, col, fname, title)
        lines.append(f"### {col}\n\n{rate_table(df, col).to_markdown()}\n")
    fig, ax = plt.subplots(figsize=(6.5, 4))
    sns.kdeplot(data=df, x="MonthlyCharges", hue="Churn", common_norm=False, fill=True, ax=ax)
    ax.set_title("Monthly charges by churn status (0 = stayed, 1 = churned)")
    fig.tight_layout()
    fig.savefig(FIG / "monthly_charges_by_churn.png", dpi=130)
    plt.close(fig)
    (OUT / "eda_summary.md").write_text("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
