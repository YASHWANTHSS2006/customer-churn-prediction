"""Streamlit app: score one customer or a CSV of customers.

Run:  streamlit run app.py   (after  python src/train.py)
"""
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).parent / "src"))
from predict import load_bundle, score_frame  # noqa: E402

st.set_page_config(page_title="Customer Churn Predictor", layout="centered")
st.title("Customer Churn Predictor")


@st.cache_resource
def get_bundle():
    return load_bundle()


try:
    bundle = get_bundle()
except FileNotFoundError as e:
    st.error(str(e))
    st.stop()

tab_one, tab_batch = st.tabs(["Single customer", "Upload CSV"])

with tab_one:
    c1, c2 = st.columns(2)
    contract = c1.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
    internet = c1.selectbox("Internet service", ["Fiber optic", "DSL", "No"])
    payment = c1.selectbox("Payment method", ["Electronic check", "Mailed check",
                                              "Bank transfer (automatic)", "Credit card (automatic)"])
    tenure = c2.slider("Tenure (months)", 0, 72, 12)
    monthly = c2.number_input("Monthly charges", 15.0, 130.0, 70.0)
    paperless = c2.selectbox("Paperless billing", ["Yes", "No"])
    addons = "No internet service" if internet == "No" else "No"
    row = pd.DataFrame([{
        "gender": "Male", "SeniorCitizen": 0, "Partner": "No", "Dependents": "No",
        "tenure": tenure, "PhoneService": "Yes", "MultipleLines": "No",
        "InternetService": internet, "OnlineSecurity": addons, "OnlineBackup": addons,
        "DeviceProtection": addons, "TechSupport": addons, "StreamingTV": addons,
        "StreamingMovies": addons, "Contract": contract, "PaperlessBilling": paperless,
        "PaymentMethod": payment, "MonthlyCharges": monthly,
        "TotalCharges": monthly * tenure,
    }])
    if st.button("Predict churn risk"):
        res = score_frame(row, bundle).iloc[0]
        st.metric("Churn risk", f"{res['churn_risk'] * 100:.0f}%")
        st.write("High risk: contact with a retention offer." if res["high_risk"]
                 else "Lower risk.")
        st.caption("Other fields use default values (no add-ons, no partner or dependents).")

with tab_batch:
    up = st.file_uploader("CSV with the Telco customer columns", type="csv")
    if up is not None:
        scored = score_frame(pd.read_csv(up), bundle).sort_values("churn_risk", ascending=False)
        st.write(f"{int(scored['high_risk'].sum())} of {len(scored)} customers flagged high risk")
        st.dataframe(scored.head(100))
        st.download_button("Download scored CSV", scored.to_csv(index=False), "scored_customers.csv")
